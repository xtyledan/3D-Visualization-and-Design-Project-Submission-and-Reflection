///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// declaration of global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";

    // Texture tags
    const std::string BRICK_TEXTURE = "BRICK_TEXTURE";
    const std::string BRICK2_TEXTURE = "BRICK2_TEXTURE";
}

SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    // free up the allocated memory
    m_pShaderManager = NULL;
    if (NULL != m_basicMeshes)
    {
        delete m_basicMeshes;
        m_basicMeshes = NULL;
    }
    // clear the collection of defined materials
    m_objectMaterials.clear();
}

bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
    if (image)
    {
        std::cout << "Successfully loaded image:" << filename
            << ", width:" << width << ", height:" << height
            << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0,
                GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        else if (colorChannels == 4)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0,
                GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            std::cout << "Not implemented to handle image with "
                << colorChannels << " channels" << std::endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;
        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;
    return false;
}

void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glGenTextures(1, &m_textureIDs[i].ID);
    }
}

int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && !bFound)
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
        {
            index++;
        }
    }
    return (textureID);
}

int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && !bFound)
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
        {
            index++;
        }
    }
    return (textureSlot);
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.f, 0.f, 0.f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.f, 1.f, 0.f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.f, 0.f, 1.f));
    glm::mat4 translate = glm::translate(positionXYZ);

    glm::mat4 modelView = translate * rotationZ * rotationY * rotationX * scale;

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureSlot = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    }
}

void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        // find the defined material that matches the tag
        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            // pass the material properties into the shader
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  PrepareScene()
 *  (unchanged: loads shapes & two textures)
 ***********************************************************/
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    SetupSceneLights();

    // Load shape meshes
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadPyramid4Mesh();  // 4-sided pyramid

    // Load 2 textures
    CreateGLTexture("textures/brick_seamless.jpg", BRICK_TEXTURE);
    CreateGLTexture("textures/brick_2_seamless.jpg", BRICK2_TEXTURE);

    // Bind them
    BindGLTextures();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{

    SetShaderMaterial("cement");  // Base
    SetShaderMaterial("gold");    // Cylinder
    SetShaderMaterial("wood");    // Plank
    SetShaderMaterial("tile");    // Box under sphere
    SetShaderMaterial("glass");   // Sphere
    SetShaderMaterial("clay");    // Cone

    // declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    //----------------------------------------------------
    // 1) PLANE
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 0.0f;
        positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // Brick1 texture for plane
        SetShaderTexture("brick1");
        SetTextureUVScale(5.0f, 5.0f);  // Increase UV scale to reduce distortion

        m_basicMeshes->DrawPlaneMesh();
    }

    //----------------------------------------------------
    // 2) CYLINDER (RED)
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(0.9f, 2.8f, 0.9f);
        XrotationDegrees = 90.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = -15.0f;
        positionXYZ = glm::vec3(0.0f, 0.9f, 0.4f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // red color
        SetShaderColor(1.0f, 0.0f, 0.0f, 1.0f);

        m_basicMeshes->DrawCylinderMesh();
    }

    //----------------------------------------------------
    // 3) TALL BOX (SECOND BRICK TEXTURE)
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(1.0f, 9.0f, 1.3f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 95.0f;
        positionXYZ = glm::vec3(0.2f, 2.27f, 2.0f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // second brick
        SetShaderTexture("brick2");
        SetTextureUVScale(2.0f, 2.0f);

        m_basicMeshes->DrawBoxMesh();
    }

    //----------------------------------------------------
    // 4) SECOND BOX (MAGENTA)
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(1.7f, 1.5f, 1.5f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 40.0f;
        ZrotationDegrees = 8.0f;
        positionXYZ = glm::vec3(3.3f, 3.85f, 2.19f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // magenta color
        SetShaderColor(1.0f, 0.0f, 1.0f, 1.0f);

        m_basicMeshes->DrawBoxMesh();
    }

    //----------------------------------------------------
    // 5) SPHERE (YELLOW)
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 0.0f;
        positionXYZ = glm::vec3(3.1f, 5.6f, 2.5f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // yellow color
        SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f);

        m_basicMeshes->DrawSphereMesh();
    }

    //----------------------------------------------------
    // 6) CONE (GREEN)
    //----------------------------------------------------
    {
        scaleXYZ = glm::vec3(1.2f, 4.0f, 1.2f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 5.0f;
        positionXYZ = glm::vec3(-3.3f, 2.5f, 2.0f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // green color
        SetShaderColor(0.0f, 1.0f, 0.0f, 1.0f);

        m_basicMeshes->DrawConeMesh(true);
    }

    //----------------------------------------------------
    // 9) PYRAMID ON THE LEFT
    //----------------------------------------------------
    {
        // If you'd like a pyramid, here's one on the left side
        glm::vec3 scaleXYZ = glm::vec3(1.0f, 1.5f, 0.8f);
        XrotationDegrees = 0.0f;
        YrotationDegrees = 0.0f;
        ZrotationDegrees = 0.0f;
        positionXYZ = glm::vec3(-3.3f, 3.50f, 2.0f);

        SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

        // you can choose to color it or texture it
        // e.g. color purple:
        // SetShaderColor(0.6f, 0.0f, 0.8f, 1.0f);

        // or apply the brick texture:
        SetShaderTexture("brick1");
        SetTextureUVScale(1.0f, 1.0f);

        m_basicMeshes->DrawPyramid4Mesh();
    }
}

void SceneManager::SetupSceneLights()
{
    // Enable lighting in the shader
    m_pShaderManager->setBoolValue("bUseLighting", true);

    // Reddish-Pink Main Light (Warm Key Light)
    m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(3.0f, 4.5f, 2.0f));
    m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.3f, 0.05f, 0.05f)); // Lower ambient
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.0f, 0.4f, 0.4f));   // Strong diffuse effect
    m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 0.5f, 0.5f)); // More realistic highlights
    m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[0].linear", 0.09f);
    m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.032f);
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

    // Purple-Tinted Secondary Light (Fill Light)
    m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-2.0f, 2.5f, 5.0f));
    m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.05f, 0.0f, 0.1f));   // Subtle purple ambient
    m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.7f, 0.1f, 0.8f));    // Softer purple hue
    m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.9f, 0.3f, 1.0f));  // Balanced specular effect
    m_pShaderManager->setFloatValue("pointLights[1].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[1].linear", 0.07f);
    m_pShaderManager->setFloatValue("pointLights[1].quadratic", 0.017f);
    m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

    // Cool Blue Overhead Light (Global Fill Light)
    m_pShaderManager->setVec3Value("pointLights[2].position", glm::vec3(0.0f, 6.0f, 2.0f));
    m_pShaderManager->setVec3Value("pointLights[2].ambient", glm::vec3(0.1f, 0.1f, 0.2f));   // Cool blue ambient
    m_pShaderManager->setVec3Value("pointLights[2].diffuse", glm::vec3(0.5f, 0.5f, 1.0f));   // Soft cool fill light
    m_pShaderManager->setVec3Value("pointLights[2].specular", glm::vec3(0.6f, 0.6f, 1.0f));  // Softer highlights
    m_pShaderManager->setFloatValue("pointLights[2].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[2].linear", 0.045f);
    m_pShaderManager->setFloatValue("pointLights[2].quadratic", 0.0075f);
    m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
}

void SceneManager::DefineObjectMaterials()
{
    // Gold Material (for the bottom cylinder)
    OBJECT_MATERIAL goldMaterial;
    goldMaterial.diffuseColor = glm::vec3(0.8f, 0.6f, 0.2f);
    goldMaterial.specularColor = glm::vec3(1.0f, 0.9f, 0.7f);
    goldMaterial.shininess = 32.0f;
    goldMaterial.tag = "gold";
    m_objectMaterials.push_back(goldMaterial);

    // Cement Material (for the base plane)
    OBJECT_MATERIAL cementMaterial;
    cementMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
    cementMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
    cementMaterial.shininess = 2.0f;
    cementMaterial.tag = "cement";
    m_objectMaterials.push_back(cementMaterial);

    // Wood Material (for the plank)
    OBJECT_MATERIAL woodMaterial;
    woodMaterial.diffuseColor = glm::vec3(0.4f, 0.3f, 0.1f);
    woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
    woodMaterial.shininess = 5.0f;
    woodMaterial.tag = "wood";
    m_objectMaterials.push_back(woodMaterial);

    // Tile Material (for the box under the sphere)
    OBJECT_MATERIAL tileMaterial;
    tileMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
    tileMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
    tileMaterial.shininess = 30.0f;
    tileMaterial.tag = "tile";
    m_objectMaterials.push_back(tileMaterial);

    // Glass Material (for the sphere)
    OBJECT_MATERIAL glassMaterial;
    glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
    glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
    glassMaterial.shininess = 80.0f;
    glassMaterial.tag = "glass";
    m_objectMaterials.push_back(glassMaterial);

    // Clay Material (for the cone)
    OBJECT_MATERIAL clayMaterial;
    clayMaterial.diffuseColor = glm::vec3(0.7f, 0.4f, 0.3f);
    clayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
    clayMaterial.shininess = 4.0f;
    clayMaterial.tag = "clay";
    m_objectMaterials.push_back(clayMaterial);
}